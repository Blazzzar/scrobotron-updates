<?php
/**
 * Scrobotron app shell. Served at /scrobotron.html
 * @var array $scrobotron_cfg
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Scrobotron — replace the caption on a GIF</title>
<link rel="stylesheet" href="<?php echo esc_url( $scrobotron_cfg['css'] ); ?>">
</head>
<body class="scrobotron">
<div class="wrap">

  <header class="top">
    <div class="brand">SCROBOTRON</div>
    <p class="tag"><b>This replaces the caption on a GIF — it doesn't add to it.</b>
       Drop or paste a GIF and it lands in Captured, exactly as it arrived. Write your caption at the
       Assimilator: it strips the old caption and watermark as it burns in your new one, and the finished GIF
       lands in Assimilated. The libraries are shared — whatever you make, everyone here can see.</p>
  </header>

  <div class="cols">

    <!-- ============ IN ============ -->
    <section class="panel" id="lib-a">
      <div class="panel-hd">
        <h2>Captured <span class="sub">Sources, as dropped</span></h2>
        <span class="tally" id="count-a">00</span>
      </div>
      <div class="panel-bd">
        <label class="drop" id="drop" for="file">
          <span class="drop-title">CAPTURE BAY</span>
          <strong>Drop GIFs from the outer world here</strong>
          <small>Captured exactly as they arrive. The old caption is stripped later, when you assimilate. Resistance is futile.</small>
          <span class="drop-status" id="drop-status" hidden></span>
          <input type="file" id="file" accept="image/gif" multiple>
        </label>
        <button type="button" class="paste" id="paste">Paste a GIF from your clipboard</button>
        <p class="lib-empty">Nothing yet.<br>Drop or paste an animated GIF — it's captured exactly as it is.</p>
        <div class="lib-grid"></div>
      </div>
      <div class="panel-ft">
        <button class="dl" id="dl-a" disabled>Download Captured (.zip)</button>
        <button class="dl danger" id="clr-a" hidden disabled>Empty Captured</button>
      </div>
    </section>

    <!-- ============ BENCH ============ -->
    <section class="panel">
      <div class="panel-hd"><h2>Assimilator <span class="sub">Strip the old, write the new</span></h2></div>
      <div class="panel-bd">

        <p class="bench-empty" id="bench-empty">
          Pick a GIF from Captured,<br>then write the caption you want on it.
        </p>

        <div id="bench-live" hidden>
          <div class="stage">
            <span class="frame"><img id="src-img" alt="Selected source GIF"><span class="mark" id="mark" hidden></span></span>
          </div>
          <p class="src-name" id="src-name"></p>
          <p class="verdict" id="verdict"></p>

          <div class="readout-wrap"><canvas id="readout"></canvas></div>

          <div class="field">
            <label for="caption">New caption</label>
            <input type="text" id="caption" placeholder="SCROBOTS COMPILE!" autocomplete="off" spellcheck="false">
          </div>

          <div class="row">
            <div class="field">
              <label for="font">Font</label>
              <select id="font"></select>
            </div>
            <div class="field">
              <label for="color">Colour</label>
              <select id="color">
                <option value="green">Green</option><option value="amber">Amber</option>
                <option value="red">Red</option><option value="cyan">Cyan</option><option value="white">White</option>
              </select>
            </div>
            <div class="field">
              <label for="mode">Where it goes</label>
              <select id="mode">
                <option value="cover">Over the picture</option>
                <option value="extend">In a bar below</option>
              </select>
            </div>
            <div class="field">
              <label for="lines">Lines</label>
              <select id="lines"><option value="1">One</option><option value="2">Two</option><option value="3">Three</option></select>
            </div>
            <div class="field">
              <label for="speed">Reveal</label>
              <select id="speed"><option value="1">Fast</option><option value="2" selected>Normal</option><option value="3">Slow</option></select>
            </div>
          </div>

          <button class="go" id="go" disabled>Assimilate</button>
          <p class="stat" id="stat"></p>
        </div>

      </div>
    </section>

    <!-- ============ OUT ============ -->
    <section class="panel" id="lib-b">
      <div class="panel-hd">
        <h2>Assimilated <span class="sub">Finished GIFs</span></h2>
        <span class="tally" id="count-b">00</span>
      </div>
      <div class="panel-bd">
        <p class="lib-empty">Nothing yet.<br>Assimilated GIFs land here.</p>
        <div class="lib-grid"></div>
      </div>
      <div class="panel-ft">
        <button class="dl" id="dl-b" disabled>Download Assimilated (.zip)</button>
        <button class="dl danger" id="clr-b" hidden disabled>Empty Assimilated</button>
      </div>
    </section>

  </div>
</div>

<dialog id="viewer" class="viewer" aria-label="GIF viewer">
  <div class="viewer-panel">
    <button class="viewer-x" id="viewer-x" aria-label="Close viewer">&times;</button>
    <div class="viewer-stage"><img id="viewer-img" alt=""></div>
    <div class="viewer-foot">
      <div class="viewer-meta">
        <span class="viewer-name" id="viewer-name"></span>
        <span class="viewer-tags"><span id="viewer-lib"></span><span id="viewer-dims"></span><span id="viewer-size"></span></span>
      </div>
      <div class="viewer-act">
        <button class="mini" id="viewer-use">Use this GIF</button>
        <a class="mini" id="viewer-save" download>Save</a>
        <button class="mini danger" id="viewer-del">Remove</button>
      </div>
    </div>
  </div>
</dialog>

<script>window.SCROBOTRON = <?php echo wp_json_encode( $scrobotron_cfg['js_cfg'] ); ?>;</script>
<script src="<?php echo esc_url( $scrobotron_cfg['js'] ); ?>"></script>
</body>
</html>
