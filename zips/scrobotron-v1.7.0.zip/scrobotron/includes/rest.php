<?php
/**
 * Scrobotron REST API — list / add / remove / zip for libraries A and B.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function scrobotron_perm() {
	if ( ! scrobotron_can_use() ) {
		return new WP_Error(
			'scrobotron_forbidden',
			__( 'Scrobotron is closed on this site.', 'scrobotron' ),
			array( 'status' => 403 )
		);
	}
	// If a shared passkey is set, the library API is only for visitors who have
	// entered it (the page sends the same-origin cookie with each request), so
	// the JSON endpoints aren't an open back door around the gate.
	if ( ! scrobotron_gate_passed() ) {
		return new WP_Error(
			'scrobotron_locked',
			__( 'This Scrobotron needs a passkey. Open the page and enter it first.', 'scrobotron' ),
			array( 'status' => 401 )
		);
	}
	return true;
}

/** Deleting is checked separately and more strictly than using the tool. */
function scrobotron_perm_delete() {
	return scrobotron_can_delete() ? true : new WP_Error(
		'scrobotron_forbidden_delete',
		__( 'Only the site owner can delete from the libraries.', 'scrobotron' ),
		array( 'status' => 403 )
	);
}

/** Only ever touch plain .gif files inside our own folder. */
function scrobotron_safe_name( $name ) {
	$name = sanitize_file_name( wp_basename( $name ) );
	if ( ! preg_match( '/\.gif$/i', $name ) ) { $name .= '.gif'; }
	return $name;
}

/**
 * Find the real file behind a requested name.
 *
 * Do NOT rebuild the path by sanitising the name: sanitize_file_name() collapses
 * runs of hyphens, so "a--b.gif" on disk becomes "a-b.gif" and the lookup misses
 * a file that is really there. Instead, compare against the actual directory
 * listing. That is exact, and it is also safer — the only paths this can ever
 * return came out of glob() on our own folder, so no traversal is possible.
 *
 * @return string|null full path, or null if the library has no such file
 */
function scrobotron_find_file( $which, $requested ) {
	$d   = scrobotron_dir( $which );
	$req = wp_basename( urldecode( (string) $requested ) );
	foreach ( (array) glob( $d['path'] . '/*.gif' ) as $f ) {
		if ( wp_basename( $f ) === $req ) { return $f; }
	}
	return null;
}

function scrobotron_list( $which ) {
	$d     = scrobotron_dir( $which );
	$out   = array();
	$files = glob( $d['path'] . '/*.gif' ) ?: array();
	// newest first, so the thing you just made is at the top
	usort( $files, function ( $a, $b ) { return filemtime( $b ) <=> filemtime( $a ); } );
	foreach ( $files as $f ) {
		$n     = wp_basename( $f );
		$out[] = array(
			'name'  => $n,
			'url'   => $d['url'] . '/' . rawurlencode( $n ),
			'size'  => filesize( $f ),
			'added' => filemtime( $f ),
		);
	}
	return $out;
}

add_action( 'rest_api_init', function () {

	register_rest_route( 'scrobotron/v1', '/lib/(?P<which>[ab])', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => 'scrobotron_perm',
			'callback'            => function ( $r ) {
				return rest_ensure_response( scrobotron_list( $r['which'] ) );
			},
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => 'scrobotron_perm',
			'callback'            => function ( $r ) {
				if ( ! scrobotron_rate_ok() ) {
					return new WP_Error(
						'scrobotron_rate',
						__( 'That is a lot of GIFs at once. Give it an hour and try again.', 'scrobotron' ),
						array( 'status' => 429 )
					);
				}
				$files = $r->get_file_params();
				if ( empty( $files['file'] ) ) {
					return new WP_Error( 'scrobotron_no_file', __( 'No file arrived. Try dropping the GIF again.', 'scrobotron' ), array( 'status' => 400 ) );
				}
				$file = $files['file'];

				// must really be a GIF, not just named like one
				$type = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array( 'gif' => 'image/gif' ) );
				$mime = function_exists( 'mime_content_type' ) ? @mime_content_type( $file['tmp_name'] ) : $type['type'];
				if ( 'image/gif' !== $mime ) {
					return new WP_Error( 'scrobotron_not_gif', __( 'That file is not a GIF.', 'scrobotron' ), array( 'status' => 415 ) );
				}
				$max = (int) apply_filters( 'scrobotron_max_bytes', 12 * MB_IN_BYTES );
				if ( filesize( $file['tmp_name'] ) > $max ) {
					return new WP_Error( 'scrobotron_too_big', sprintf( __( 'That GIF is over the %d MB limit.', 'scrobotron' ), $max / MB_IN_BYTES ), array( 'status' => 413 ) );
				}

				$d    = scrobotron_dir( $r['which'] );
				$name = scrobotron_safe_name( $file['name'] );
				$dest = $d['path'] . '/' . $name;

				// The app asks to overwrite in exactly one case: writing the
				// cleaned source back over the copy you just dropped in.
				// Everywhere else a name clash gets a new number.
				$replace = ! empty( $r->get_param( 'replace' ) );
				if ( $replace ) {
					// Target the real file, since the name on disk may differ
					// from the sanitised form (hyphen runs get collapsed).
					$existing = scrobotron_find_file( $r['which'], $file['name'] );
					if ( $existing ) {
						$dest = $existing;
						$name = wp_basename( $existing );
					}
				} else {
					$i = 1;
					while ( file_exists( $dest ) ) {
						$name = preg_replace( '/\.gif$/i', '', scrobotron_safe_name( $file['name'] ) ) . '-' . ( ++$i ) . '.gif';
						$dest = $d['path'] . '/' . $name;
					}
				}
				if ( ! @move_uploaded_file( $file['tmp_name'], $dest ) && ! @copy( $file['tmp_name'], $dest ) ) {
					return new WP_Error( 'scrobotron_write', __( 'Could not write to the uploads folder.', 'scrobotron' ), array( 'status' => 500 ) );
				}
				@chmod( $dest, 0644 );
				return rest_ensure_response( array( 'name' => $name, 'url' => $d['url'] . '/' . rawurlencode( $name ) ) );
			},
		),
		array(
			'methods'             => 'DELETE',
			'permission_callback' => 'scrobotron_perm_delete',
			'callback'            => function ( $r ) {
				// Empty a whole library. Owner only, same as single deletes.
				$d     = scrobotron_dir( $r['which'] );
				$files = (array) glob( $d['path'] . '/*.gif' );
				$gone  = 0;
				$stuck = array();
				foreach ( $files as $f ) {
					if ( @unlink( $f ) ) { $gone++; } else { $stuck[] = wp_basename( $f ); }
				}
				if ( $stuck ) {
					return new WP_Error(
						'scrobotron_unlink',
						sprintf(
							/* translators: %s: comma separated file names */
							__( 'Deleted %1$d, but these would not go: %2$s. Check folder permissions.', 'scrobotron' ),
							$gone,
							implode( ', ', $stuck )
						),
						array( 'status' => 500 )
					);
				}
				return rest_ensure_response( array( 'emptied' => $r['which'], 'deleted' => $gone ) );
			},
		),
	) );

	register_rest_route( 'scrobotron/v1', '/lib/(?P<which>[ab])/(?P<name>[^/]+)', array(
		'methods'             => 'DELETE',
		'permission_callback' => 'scrobotron_perm_delete',
		'callback'            => function ( $r ) {
			$path = scrobotron_find_file( $r['which'], $r['name'] );
			if ( ! $path ) {
				// Say so rather than reporting a success that never happened.
				return new WP_Error(
					'scrobotron_not_found',
					__( 'That GIF is not in the library — it may already be gone. Refresh the page.', 'scrobotron' ),
					array( 'status' => 404 )
				);
			}
			if ( ! @unlink( $path ) ) {
				return new WP_Error(
					'scrobotron_unlink',
					__( 'Could not delete that file. Check the permissions on the uploads folder.', 'scrobotron' ),
					array( 'status' => 500 )
				);
			}
			return rest_ensure_response( array( 'deleted' => wp_basename( $path ) ) );
		},
	) );

	register_rest_route( 'scrobotron/v1', '/zip/(?P<which>[ab])', array(
		'methods'             => 'GET',
		'permission_callback' => 'scrobotron_perm',
		'callback'            => function ( $r ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				return new WP_Error( 'scrobotron_nozip', __( 'This server has no ZipArchive, so bulk download is unavailable. Save GIFs individually.', 'scrobotron' ), array( 'status' => 501 ) );
			}
			$which = $r['which'];
			$d     = scrobotron_dir( $which );
			$files = glob( $d['path'] . '/*.gif' ) ?: array();
			if ( ! $files ) {
				return new WP_Error( 'scrobotron_empty', __( 'That library is empty.', 'scrobotron' ), array( 'status' => 404 ) );
			}
			$tmp = trailingslashit( get_temp_dir() ) . 'scrobotron-' . $which . '-' . time() . '.zip';
			$zip = new ZipArchive();
			if ( true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				return new WP_Error( 'scrobotron_zip', __( 'Could not build the zip.', 'scrobotron' ), array( 'status' => 500 ) );
			}
			foreach ( $files as $f ) { $zip->addFile( $f, wp_basename( $f ) ); }
			$zip->close();

			nocache_headers();
			header( 'Content-Type: application/zip' );
			header( 'Content-Disposition: attachment; filename="scrobotron-library-' . $which . '.zip"' );
			header( 'Content-Length: ' . filesize( $tmp ) );
			readfile( $tmp );
			@unlink( $tmp );
			exit;
		},
	) );
} );
