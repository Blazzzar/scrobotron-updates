<?php
/**
 * Scrobotron REST API — list / add / remove / zip for libraries A and B.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function scrobotron_perm() {
	if ( ! scrobotron_can_use() ) {
		return new WP_Error(
			'scrobotron_forbidden',
			__( 'Scrobotron is closed on this site.', 'scrobotron' ),
			array( 'status' => 403 )
		);
	}
	// If a shared passkey is set, the library API is only for visitors who have
	// entered it (the page sends the same-origin cookie with each request), so
	// the JSON endpoints aren't an open back door around the gate.
	if ( ! scrobotron_gate_passed() ) {
		return new WP_Error(
			'scrobotron_locked',
			__( 'This Scrobotron needs a passkey. Open the page and enter it first.', 'scrobotron' ),
			array( 'status' => 401 )
		);
	}
	return true;
}

/** Deleting is checked separately and more strictly than using the tool. */
function scrobotron_perm_delete() {
	return scrobotron_can_delete() ? true : new WP_Error(
		'scrobotron_forbidden_delete',
		__( 'Only the site owner can delete from the libraries.', 'scrobotron' ),
		array( 'status' => 403 )
	);
}

/** Only ever touch plain .gif files inside our own folder. */
function scrobotron_safe_name( $name ) {
	$name = sanitize_file_name( wp_basename( $name ) );
	if ( ! preg_match( '/\.gif$/i', $name ) ) { $name .= '.gif'; }
	return $name;
}

/**
 * Find the real file behind a requested name.
 *
 * Do NOT rebuild the path by sanitising the name: sanitize_file_name() collapses
 * runs of hyphens, so "a--b.gif" on disk becomes "a-b.gif" and the lookup misses
 * a file that is really there. Instead, compare against the actual directory
 * listing. That is exact, and it is also safer — the only paths this can ever
 * return came out of glob() on our own folder, so no traversal is possible.
 *
 * @return string|null full path, or null if the library has no such file
 */
function scrobotron_find_file( $which, $requested ) {
	$d   = scrobotron_dir( $which );
	$req = wp_basename( urldecode( (string) $requested ) );
	foreach ( (array) glob( $d['path'] . '/*.gif' ) as $f ) {
		if ( wp_basename( $f ) === $req ) { return $f; }
	}
	return null;
}

function scrobotron_list( $which ) {
	$d     = scrobotron_dir( $which );
	$out   = array();
	$files = glob( $d['path'] . '/*.gif' ) ?: array();
	// newest first, so the thing you just made is at the top
	usort( $files, function ( $a, $b ) { return filemtime( $b ) <=> filemtime( $a ); } );
	foreach ( $files as $f ) {
		$n     = wp_basename( $f );
		$out[] = array(
			'name'  => $n,
			'url'   => $d['url'] . '/' . rawurlencode( $n ),
			'size'  => filesize( $f ),
			'added' => filemtime( $f ),
		);
	}
	return $out;
}

add_action( 'rest_api_init', function () {

	register_rest_route( 'scrobotron/v1', '/lib/(?P<which>[ab])', array(
		array(
			'methods'             => 'GET',
			'permission_callback' => 'scrobotron_perm',
			'callback'            => function ( $r ) {
				return rest_ensure_response( scrobotron_list( $r['which'] ) );
			},
		),
		array(
			'methods'             => 'POST',
			'permission_callback' => 'scrobotron_perm',
			'callback'            => function ( $r ) {
				if ( ! scrobotron_rate_ok() ) {
					return new WP_Error(
						'scrobotron_rate',
						__( 'That is a lot of GIFs at once. Give it an hour and try again.', 'scrobotron' ),
						array( 'status' => 429 )
					);
				}
				$files = $r->get_file_params();
				if ( empty( $files['file'] ) ) {
					return new WP_Error( 'scrobotron_no_file', __( 'No file arrived. Try dropping the GIF again.', 'scrobotron' ), array( 'status' => 400 ) );
				}
				$file = $files['file'];

				// must really be a GIF, not just named like one
				$type = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array( 'gif' => 'image/gif' ) );
				$mime = function_exists( 'mime_content_type' ) ? @mime_content_type( $file['tmp_name'] ) : $type['type'];
				if ( 'image/gif' !== $mime ) {
					return new WP_Error( 'scrobotron_not_gif', __( 'That file is not a GIF.', 'scrobotron' ), array( 'status' => 415 ) );
				}
				$max = (int) apply_filters( 'scrobotron_max_bytes', 12 * MB_IN_BYTES );
				if ( filesize( $file['tmp_name'] ) > $max ) {
					return new WP_Error( 'scrobotron_too_big', sprintf( __( 'That GIF is over the %d MB limit.', 'scrobotron' ), $max / MB_IN_BYTES ), array( 'status' => 413 ) );
				}

				$d    = scrobotron_dir( $r['which'] );
				$name = scrobotron_safe_name( $file['name'] );
				$dest = $d['path'] . '/' . $name;

				// The app asks to overwrite in exactly one case: writing the
				// cleaned source back over the copy you just dropped in.
				// Everywhere else a name clash gets a new number.
				$replace = ! empty( $r->get_param( 'replace' ) );
				if ( $replace ) {
					// Target the real file, since the name on disk may differ
					// from the sanitised form (hyphen runs get collapsed).
					$existing = scrobotron_find_file( $r['which'], $file['name'] );
					if ( $existing ) {
						$dest = $existing;
						$name = wp_basename( $existing );
					}
				} else {
					$i = 1;
					while ( file_exists( $dest ) ) {
						$name = preg_replace( '/\.gif$/i', '', scrobotron_safe_name( $file['name'] ) ) . '-' . ( ++$i ) . '.gif';
						$dest = $d['path'] . '/' . $name;
					}
				}
				if ( ! @move_uploaded_file( $file['tmp_name'], $dest ) && ! @copy( $file['tmp_name'], $dest ) ) {
					return new WP_Error( 'scrobotron_write', __( 'Could not write to the uploads folder.', 'scrobotron' ), array( 'status' => 500 ) );
				}
				@chmod( $dest, 0644 );
				return rest_ensure_response( array( 'name' => $name, 'url' => $d['url'] . '/' . rawurlencode( $name ) ) );
			},
		),
		array(
			'methods'             => 'DELETE',
			'permission_callback' => 'scrobotron_perm_delete',
			'callback'            => function ( $r ) {
				// Empty a whole library. Owner only, same as single deletes.
				$d     = scrobotron_dir( $r['which'] );
				$files = (array) glob( $d['path'] . '/*.gif' );
				$gone  = 0;
				$stuck = array();
				foreach ( $files as $f ) {
					if ( @unlink( $f ) ) { $gone++; } else { $stuck[] = wp_basename( $f ); }
				}
				if ( $stuck ) {
					return new WP_Error(
						'scrobotron_unlink',
						sprintf(
							/* translators: %s: comma separated file names */
							__( 'Deleted %1$d, but these would not go: %2$s. Check folder permissions.', 'scrobotron' ),
							$gone,
							implode( ', ', $stuck )
						),
						array( 'status' => 500 )
					);
				}
				return rest_ensure_response( array( 'emptied' => $r['which'], 'deleted' => $gone ) );
			},
		),
	) );

	register_rest_route( 'scrobotron/v1', '/lib/(?P<which>[ab])/(?P<name>[^/]+)', array(
		'methods'             => 'DELETE',
		'permission_callback' => 'scrobotron_perm_delete',
		'callback'            => function ( $r ) {
			$path = scrobotron_find_file( $r['which'], $r['name'] );
			if ( ! $path ) {
				// Say so rather than reporting a success that never happened.
				return new WP_Error(
					'scrobotron_not_found',
					__( 'That GIF is not in the library — it may already be gone. Refresh the page.', 'scrobotron' ),
					array( 'status' => 404 )
				);
			}
			if ( ! @unlink( $path ) ) {
				return new WP_Error(
					'scrobotron_unlink',
					__( 'Could not delete that file. Check the permissions on the uploads folder.', 'scrobotron' ),
					array( 'status' => 500 )
				);
			}
			return rest_ensure_response( array( 'deleted' => wp_basename( $path ) ) );
		},
	) );

	register_rest_route( 'scrobotron/v1', '/zip/(?P<which>[ab])', array(
		'methods'             => 'GET',
		'permission_callback' => 'scrobotron_perm',
		'callback'            => function ( $r ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				return new WP_Error( 'scrobotron_nozip', __( 'This server has no ZipArchive, so bulk download is unavailable. Save GIFs individually.', 'scrobotron' ), array( 'status' => 501 ) );
			}
			$which = $r['which'];
			$d     = scrobotron_dir( $which );
			$files = glob( $d['path'] . '/*.gif' ) ?: array();
			if ( ! $files ) {
				return new WP_Error( 'scrobotron_empty', __( 'That library is empty.', 'scrobotron' ), array( 'status' => 404 ) );
			}
			$tmp = trailingslashit( get_temp_dir() ) . 'scrobotron-' . $which . '-' . time() . '.zip';
			$zip = new ZipArchive();
			if ( true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				return new WP_Error( 'scrobotron_zip', __( 'Could not build the zip.', 'scrobotron' ), array( 'status' => 500 ) );
			}
			foreach ( $files as $f ) { $zip->addFile( $f, wp_basename( $f ) ); }
			$zip->close();

			nocache_headers();
			header( 'Content-Type: application/zip' );
			header( 'Content-Disposition: attachment; filename="scrobotron-library-' . $which . '.zip"' );
			header( 'Content-Length: ' . filesize( $tmp ) );
			readfile( $tmp );
			@unlink( $tmp );
			exit;
		},
	) );

	/*
	 * Capture by URL — the phone-friendly way in. The SERVER fetches the GIF
	 * (dodging browser CORS) and drops it into Captured. Guard rails:
	 * wp_http_validate_url + wp_safe_remote_get refuse local/private targets,
	 * the response is size-capped, and the bytes must really start GIF87a/89a.
	 */
	register_rest_route( 'scrobotron/v1', '/fetch', array(
		'methods'             => 'POST',
		'permission_callback' => 'scrobotron_perm',
		'callback'            => function ( $r ) {
			if ( ! scrobotron_rate_ok() ) {
				return new WP_Error( 'scrobotron_rate', __( 'That is a lot of GIFs at once. Give it an hour and try again.', 'scrobotron' ), array( 'status' => 429 ) );
			}
			$url = esc_url_raw( trim( (string) $r->get_param( 'url' ) ) );
			if ( ! $url || ! preg_match( '#^https?://#i', $url ) || ! wp_http_validate_url( $url ) ) {
				return new WP_Error( 'scrobotron_bad_url', __( 'That does not look like a fetchable web address.', 'scrobotron' ), array( 'status' => 400 ) );
			}
			$max = (int) apply_filters( 'scrobotron_max_bytes', 12 * MB_IN_BYTES );
			$res = wp_safe_remote_get( $url, array(
				'timeout'             => 20,
				'limit_response_size' => $max + 1024,
				'user-agent'          => 'Scrobotron/' . SCROBOTRON_VER . '; ' . home_url( '/' ),
			) );
			if ( is_wp_error( $res ) ) {
				return new WP_Error( 'scrobotron_fetch', sprintf( __( 'Could not fetch that URL: %s', 'scrobotron' ), $res->get_error_message() ), array( 'status' => 502 ) );
			}
			if ( 200 !== wp_remote_retrieve_response_code( $res ) ) {
				return new WP_Error( 'scrobotron_fetch', sprintf( __( 'That URL answered HTTP %d.', 'scrobotron' ), wp_remote_retrieve_response_code( $res ) ), array( 'status' => 502 ) );
			}
			$body = wp_remote_retrieve_body( $res );
			if ( strlen( $body ) > $max ) {
				return new WP_Error( 'scrobotron_too_big', sprintf( __( 'That GIF is over the %d MB limit.', 'scrobotron' ), $max / MB_IN_BYTES ), array( 'status' => 413 ) );
			}
			if ( 'GIF87a' !== substr( $body, 0, 6 ) && 'GIF89a' !== substr( $body, 0, 6 ) ) {
				return new WP_Error( 'scrobotron_not_gif', __( 'That URL is not an animated GIF. Use a direct .gif link.', 'scrobotron' ), array( 'status' => 415 ) );
			}

			$d    = scrobotron_dir( 'a' );
			$base = wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
			$name = scrobotron_safe_name( $base && preg_match( '/\.gif$/i', $base ) ? $base : 'captured-' . gmdate( 'His' ) . '.gif' );
			$dest = $d['path'] . '/' . $name;
			$i    = 1;
			while ( file_exists( $dest ) ) {
				$name = preg_replace( '/\.gif$/i', '', scrobotron_safe_name( $base ?: 'captured' ) ) . '-' . ( ++$i ) . '.gif';
				$dest = $d['path'] . '/' . $name;
			}
			if ( false === @file_put_contents( $dest, $body ) ) {
				return new WP_Error( 'scrobotron_write', __( 'Could not write to the uploads folder.', 'scrobotron' ), array( 'status' => 500 ) );
			}
			@chmod( $dest, 0644 );
			return rest_ensure_response( array( 'name' => $name, 'url' => $d['url'] . '/' . rawurlencode( $name ) ) );
		},
	) );

	/*
	 * GIF search — a thin proxy over Tenor v2 so the API key stays on the
	 * server. Off (501) until a key is set: option `scrobotron_tenor_key`,
	 * the SCROBOTRON_TENOR_KEY constant, or the filter of the same name.
	 * The client shows the search box only when the page config says so.
	 */
	register_rest_route( 'scrobotron/v1', '/search', array(
		'methods'             => 'GET',
		'permission_callback' => 'scrobotron_perm',
		'callback'            => function ( $r ) {
			$key = scrobotron_tenor_key();
			if ( '' === $key ) {
				return new WP_Error( 'scrobotron_nosearch', __( 'GIF search is not switched on for this site.', 'scrobotron' ), array( 'status' => 501 ) );
			}
			$q = sanitize_text_field( (string) $r->get_param( 'q' ) );
			if ( '' === $q ) {
				return new WP_Error( 'scrobotron_noquery', __( 'Type something to search for.', 'scrobotron' ), array( 'status' => 400 ) );
			}
			$ck  = 'scrobotron_search_' . md5( $q );
			$hit = get_transient( $ck );
			if ( false !== $hit ) { return rest_ensure_response( $hit ); }
			$res = wp_safe_remote_get( add_query_arg( array(
				'q'             => rawurlencode( $q ),
				'key'           => rawurlencode( $key ),
				'limit'         => 24,
				'media_filter'  => 'gif,tinygif',
				'contentfilter' => 'medium',
			), 'https://tenor.googleapis.com/v2/search' ), array( 'timeout' => 12 ) );
			if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
				return new WP_Error( 'scrobotron_search', __( 'The GIF search did not answer. Try again in a moment.', 'scrobotron' ), array( 'status' => 502 ) );
			}
			$data = json_decode( wp_remote_retrieve_body( $res ), true );
			$out  = array();
			foreach ( (array) ( $data['results'] ?? array() ) as $hit2 ) {
				$gif  = $hit2['media_formats']['gif']['url'] ?? '';
				$tiny = $hit2['media_formats']['tinygif']['url'] ?? $gif;
				if ( $gif ) {
					$out[] = array(
						'id'      => (string) ( $hit2['id'] ?? '' ),
						'desc'    => (string) ( $hit2['content_description'] ?? '' ),
						'preview' => $tiny,
						'url'     => $gif,
					);
				}
			}
			set_transient( $ck, $out, 10 * MINUTE_IN_SECONDS );
			return rest_ensure_response( $out );
		},
	) );
} );

/** The Tenor API key, or '' when search is off. */
function scrobotron_tenor_key() {
	$key = get_option( 'scrobotron_tenor_key', '' );
	if ( ! $key && defined( 'SCROBOTRON_TENOR_KEY' ) ) { $key = SCROBOTRON_TENOR_KEY; }
	return trim( (string) apply_filters( 'scrobotron_tenor_key', $key ) );
}
