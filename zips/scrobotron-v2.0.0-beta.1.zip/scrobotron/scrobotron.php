<?php
/**
 * Plugin Name:       Scrobotron
 * Plugin URI:        https://mmn.rocks/scrobotron.html
 * Description:       Replaces the caption on an animated GIF with retro 14-segment LED type. Captures sources as-is, strips the old caption/watermark when you assimilate. Optional shared-passkey gate.
 * Version:           2.0.0-beta.1
 * Update URI:        https://blazzzar.github.io/scrobotron-updates/scrobotron.json
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            MMN
 * License:           GPL-2.0-or-later
 * Text Domain:       scrobotron
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'SCROBOTRON_VER', '2.0.0-beta.1' );
define( 'SCROBOTRON_FILE', __FILE__ );
define( 'SCROBOTRON_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCROBOTRON_URL', plugin_dir_url( __FILE__ ) );
define( 'SCROBOTRON_GATE_COOKIE', 'scrobotron_gate' );

/* ============================================================
 * SELF-UPDATER — GitHub release channel (STEMMAXXER/WeIdea pattern).
 * The plugin checks the public channel manifest and offers normal
 * one-click updates on the Plugins screen (plus channel switch,
 * check-now, and rollback links). See includes/class-scro-updater.php.
 * ============================================================ */
require_once __DIR__ . '/includes/class-scro-updater.php';
require_once __DIR__ . '/includes/class-scro-updater-admin.php';
SCRO_Updater::instance();
SCRO_Updater_Admin::init();

/** The page lives at this path. Change with the scrobotron_slug filter. */
function scrobotron_slug() {
	return apply_filters( 'scrobotron_slug', 'scrobotron.html' );
}

/**
 * Who may use the tool. Open to everyone — no account, no login, no password.
 *
 * Deleting is a separate, stricter check (see below), so visitors can add GIFs
 * and write captions but can never remove anything.
 *
 * To put the lock back on:
 *   add_filter( 'scrobotron_capability', function () { return current_user_can( 'upload_files' ); } );
 */
function scrobotron_can_use() {
	return (bool) apply_filters( 'scrobotron_capability', true );
}

/* -------------------------------------------------------------------------
 * Optional shared-passkey gate.
 *
 * Off by default: with no passkey set the page stays public, exactly as before.
 * Set a passkey and every visitor must type it once before the tool loads.
 * This is a single shared phrase for the whole site, NOT a per-person login —
 * it keeps the casual public out, it is not account security.
 *
 * The owner sets the passkey WITHOUT editing this plugin (so a plugin update
 * can't wipe it). Drop a tiny file into wp-content/mu-plugins/ — a ready-made
 * one ships in this plugin at  install/scrobotron-passkey.php  with setup notes
 * in  install/PASSKEY-INSTALL.md. Either of these turns the gate on:
 *
 *   // wp-content/mu-plugins/scrobotron-passkey.php
 *   add_filter( 'scrobotron_passkey', function () { return 'your-phrase'; } );
 *
 *   // or, in wp-config.php:
 *   define( 'SCROBOTRON_PASSKEY', 'your-phrase' );
 * ---------------------------------------------------------------------- */

/** The active passkey, or '' when the gate is off. */
function scrobotron_passkey() {
	$key = defined( 'SCROBOTRON_PASSKEY' ) ? SCROBOTRON_PASSKEY : '';
	return trim( (string) apply_filters( 'scrobotron_passkey', $key ) );
}

/**
 * The cookie value that proves a visitor typed the current passkey. It is an
 * HMAC of the passkey with the site's own auth salt, so it can't be forged, and
 * it changes the moment you change the passkey — old cookies stop working.
 */
function scrobotron_gate_token( $passkey ) {
	return hash_hmac( 'sha256', 'scrobotron-gate-v1', $passkey . wp_salt( 'auth' ) );
}

/** True if this visitor may pass the gate right now (no rendering, no side effects). */
function scrobotron_gate_passed() {
	$passkey = scrobotron_passkey();
	if ( '' === $passkey ) { return true; }                     // gate off
	if ( current_user_can( 'upload_files' ) ) { return true; }  // signed-in staff skip it
	$token = scrobotron_gate_token( $passkey );
	return isset( $_COOKIE[ SCROBOTRON_GATE_COOKIE ] )
		&& hash_equals( $token, (string) wp_unslash( $_COOKIE[ SCROBOTRON_GATE_COOKIE ] ) );
}

/** Modest brute-force throttle: a handful of tries per IP per few minutes. */
function scrobotron_gate_attempt_ok() {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$key = 'scrobotron_gate_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= 10 ) { return false; }
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );
	return true;
}

/**
 * Hold the Scrobotron page behind the passkey when one is set. Returns when the
 * visitor may pass; otherwise it renders the prompt (or a redirect on success)
 * and exits, so the page never loads for anyone who hasn't entered the passkey.
 */
function scrobotron_gate() {
	$passkey = scrobotron_passkey();
	if ( '' === $passkey ) { return; }
	if ( scrobotron_gate_passed() ) { return; }

	$error = '';
	if ( isset( $_POST['scrobotron_pass'] ) ) {                 // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! scrobotron_gate_attempt_ok() ) {
			$error = 'Too many tries. Wait a few minutes and try again.';
		} elseif ( hash_equals( $passkey, (string) wp_unslash( $_POST['scrobotron_pass'] ) ) ) {
			setcookie( SCROBOTRON_GATE_COOKIE, scrobotron_gate_token( $passkey ), array(
				'expires'  => time() + 30 * DAY_IN_SECONDS,
				'path'     => '/',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			) );
			wp_safe_redirect( home_url( '/' . scrobotron_slug() ) );   // reload as GET
			exit;
		} else {
			$error = 'That passkey is not right.';
		}
	}

	status_header( 200 );
	nocache_headers();
	scrobotron_render_gate( $error );
	exit;
}

/** The passkey prompt — a small self-contained page in the Scrobotron palette. */
function scrobotron_render_gate( $error = '' ) {
	$action = esc_url( home_url( '/' . scrobotron_slug() ) );
	?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>Scrobotron — passkey</title>
<style>
:root{--void:#0B1010;--shell:#141C1C;--edge:#2C3D3B;--phosphor:#39FF46;--ink:#CBD9D4;--ink-dim:#5C716D;--caution:#FFB200;--r:3px;
 --ui:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Helvetica,Arial,sans-serif}
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--void);color:var(--ink);font-family:var(--ui);font-size:14px;padding:20px}
.gate{width:min(92vw,340px);background:var(--shell);border:1px solid var(--edge);border-radius:var(--r);padding:26px 22px;text-align:center}
.brand{font-family:"Courier New",monospace;font-weight:700;font-size:22px;letter-spacing:.08em;color:var(--phosphor);text-shadow:0 0 12px rgba(57,255,70,.45)}
.gate p{color:var(--ink-dim);margin:8px 0 18px;font-size:12.5px}
.gate input{width:100%;font:inherit;padding:10px;color:var(--ink);background:var(--void);border:1px solid var(--edge);border-radius:var(--r);text-align:center;letter-spacing:.06em}
.gate input:focus{outline:2px solid var(--phosphor);outline-offset:1px;border-color:var(--phosphor)}
.gate button{width:100%;margin-top:12px;padding:11px;font:inherit;font-weight:700;letter-spacing:.05em;color:var(--void);background:var(--phosphor);border:0;border-radius:var(--r);cursor:pointer}
.err{color:var(--caution);font-size:12px;margin-top:12px;min-height:1.1em}
</style>
</head>
<body>
<form class="gate" method="post" action="<?php echo $action; // phpcs:ignore WordPress.Security.EscapeOutput ?>">
	<div class="brand">SCROBOTRON</div>
	<p>Enter the passkey to continue.</p>
	<input type="password" name="scrobotron_pass" autocomplete="current-password" autofocus aria-label="Passkey">
	<button type="submit">Enter</button>
	<div class="err"><?php echo esc_html( $error ); ?></div>
</form>
</body>
</html>
	<?php
}

/**
 * Who may DELETE from the libraries. Deleting is destructive and permanent, so
 * it stays with administrators — that is you, and not the public.
 *
 * If you ever add a second administrator and want deletion pinned to just you,
 * name yourself (find your ID under Users → your profile):
 *   add_filter( 'scrobotron_owner_ids', function () { return array( 1 ); } );
 */
function scrobotron_can_delete() {
	$allowed = current_user_can( 'manage_options' );
	$owners  = array_filter( array_map( 'intval', (array) apply_filters( 'scrobotron_owner_ids', array() ) ) );
	if ( $owners ) {
		$allowed = in_array( get_current_user_id(), $owners, true );
	}
	return (bool) apply_filters( 'scrobotron_can_delete', $allowed );
}

/**
 * Because the tool is open to the public, the upload endpoint is a door onto
 * your server. Cap how many GIFs one visitor can add per hour so nobody can
 * fill your disk. Signed-in users who can upload files are not limited.
 *   add_filter( 'scrobotron_rate_limit', function () { return 100; } );  // raise
 *   add_filter( 'scrobotron_rate_limit', '__return_zero' );              // no limit
 */
function scrobotron_rate_ok() {
	if ( current_user_can( 'upload_files' ) ) { return true; }
	$max = (int) apply_filters( 'scrobotron_rate_limit', 40 );
	if ( $max <= 0 ) { return true; }
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$key = 'scrobotron_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= $max ) { return false; }
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );
	return true;
}

/** uploads/scrobotron/{a|b} — created on demand, index-protected. */
function scrobotron_dir( $which ) {
	$which = ( 'b' === $which ) ? 'b' : 'a';
	$up    = wp_upload_dir();
	$base  = trailingslashit( $up['basedir'] ) . 'scrobotron';
	$path  = $base . '/' . $which;
	if ( ! file_exists( $path ) ) {
		wp_mkdir_p( $path );
		// don't advertise the directory listing
		foreach ( array( $base, $path ) as $d ) {
			$idx = $d . '/index.html';
			if ( ! file_exists( $idx ) ) { @file_put_contents( $idx, '' ); }
		}
	}
	return array(
		'path' => $path,
		'url'  => trailingslashit( $up['baseurl'] ) . 'scrobotron/' . $which,
	);
}

/* -------------------------------------------------------------------------
 * Route: /scrobotron.html
 * ---------------------------------------------------------------------- */
add_action( 'init', function () {
	add_rewrite_rule( '^' . preg_quote( scrobotron_slug(), '#' ) . '$', 'index.php?scrobotron=1', 'top' );
} );

add_filter( 'query_vars', function ( $v ) { $v[] = 'scrobotron'; return $v; } );

/**
 * Belt and braces for the URL.
 *
 * The rewrite rule is the proper WordPress way, but rules get flushed by other
 * plugins, lost on migration, or never written if permalinks were never saved.
 * If the request reached WordPress at all, match the path ourselves — that way
 * /scrobotron.html works even with no rule in the database.
 */
add_action( 'parse_request', function ( $wp ) {
	$path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
	if ( '' !== $home && 0 === strpos( $path, $home ) ) {          // site in a subdirectory
		$path = trim( substr( $path, strlen( $home ) ), '/' );
	}
	if ( $path === scrobotron_slug() ) {
		$wp->query_vars['scrobotron'] = 1;
	}
} );

/** Put our rule back if something else flushed it away. Runs at most once a day. */
add_action( 'init', function () {
	if ( get_transient( 'scrobotron_rules_ok' ) ) { return; }
	$rules = get_option( 'rewrite_rules' );
	$key   = '^' . preg_quote( scrobotron_slug(), '#' ) . '$';
	if ( is_array( $rules ) && ! isset( $rules[ $key ] ) ) {
		flush_rewrite_rules( false );
	}
	set_transient( 'scrobotron_rules_ok', 1, DAY_IN_SECONDS );
}, 99 );

add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'scrobotron' ) ) { return; }

	if ( ! scrobotron_can_use() ) {
		// Only reachable if someone has filtered the tool closed again.
		auth_redirect();
		exit;
	}

	// Optional shared-passkey gate. Renders the prompt and exits if a passkey is
	// set and this visitor hasn't entered it; a no-op when no passkey is set.
	scrobotron_gate();

	$scrobotron_cfg = array(
		'css'    => SCROBOTRON_URL . 'assets/app.css?v=' . SCROBOTRON_VER,
		'js'     => SCROBOTRON_URL . 'assets/app.js?v=' . SCROBOTRON_VER,
		'js_cfg' => array(
			'rest'      => esc_url_raw( rest_url( 'scrobotron/v1' ) ),
			'nonce'     => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
			'fontBase'  => SCROBOTRON_URL . 'assets/fonts/',
			'ver'       => SCROBOTRON_VER,
			'canDelete' => scrobotron_can_delete(),
			'canFetch'  => true,
			'canSearch' => '' !== scrobotron_tenor_key(),
		),
	);

	status_header( 200 );
	nocache_headers();
	include SCROBOTRON_DIR . 'templates/app.php';
	exit;
} );

/* -------------------------------------------------------------------------
 * Activation / deactivation — put resources in place, make the URL resolve
 * ---------------------------------------------------------------------- */
register_activation_hook( __FILE__, function () {
	add_rewrite_rule( '^' . preg_quote( scrobotron_slug(), '#' ) . '$', 'index.php?scrobotron=1', 'top' );
	flush_rewrite_rules();
	delete_transient( 'scrobotron_rules_ok' );
	scrobotron_dir( 'a' );
	scrobotron_dir( 'b' );
} );
register_deactivation_hook( __FILE__, function () {
	delete_transient( 'scrobotron_rules_ok' );
	flush_rewrite_rules();
} );

/* -------------------------------------------------------------------------
 * Admin pointer — the tool has no settings, just a link
 * ---------------------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_media_page( 'Scrobotron', 'Scrobotron', 'upload_files', 'scrobotron', 'scrobotron_admin_page' );
} );

function scrobotron_admin_page() {
	$url = home_url( '/' . scrobotron_slug() );

	// Actually fetch the page, so we report what really happens rather than guess.
	$check = wp_remote_get( $url, array(
		'timeout'   => 8,
		'sslverify' => false,
		'headers'   => array( 'X-Scrobotron-Check' => '1' ),
	) );
	$code = is_wp_error( $check ) ? 0 : (int) wp_remote_retrieve_response_code( $check );
	$body = is_wp_error( $check ) ? '' : wp_remote_retrieve_body( $check );
	$ours = ( false !== strpos( $body, 'SCROBOTRON' ) );
	// 302/401/403 = WordPress answered and asked the visitor to log in. That's correct.
	$reached = $ours || in_array( $code, array( 302, 401, 403 ), true );

	echo '<div class="wrap"><h1>Scrobotron</h1>';
	echo '<p>Replace the caption on an animated GIF with LED type.</p>';

	if ( $reached ) {
		echo '<div class="notice notice-success inline"><p><strong>The page is live at <code>' . esc_html( $url ) . '</code>.</strong></p></div>';
		echo '<p><a class="button button-primary" href="' . esc_url( $url ) . '">Open Scrobotron</a></p>';
	} else {
		echo '<div class="notice notice-error inline"><p><strong>' . esc_html( $url ) . ' is not resolving';
		echo $code ? ' (HTTP ' . (int) $code . ').' : '.';
		echo '</strong></p></div>';
		echo '<h2>How to fix it</h2><ol>';
		echo '<li>Re-save <a href="' . esc_url( admin_url( 'options-permalink.php' ) ) . '">Settings → Permalinks</a> once. This rewrites the rules and fixes most cases.</li>';
		echo '<li>If it still 404s, your web server is probably serving <code>.html</code> as a static file and never handing the request to WordPress. Either ask your host to let <code>' . esc_html( scrobotron_slug() ) . '</code> fall through to WordPress, or switch to an extensionless path by adding this to your theme\'s <code>functions.php</code>:<br>';
		echo '<code>add_filter( \'scrobotron_slug\', function () { return \'scrobotron\'; } );</code><br>then re-save Permalinks. The tool will live at <code>' . esc_html( home_url( '/scrobotron' ) ) . '</code>.</li>';
		echo '</ol>';
	}

	echo '<h2>Where things live</h2><ul style="list-style:disc;margin-left:20px">';
	echo '<li>Captured (sources): <code>uploads/scrobotron/a</code></li>';
	echo '<li>Assimilated (finished): <code>uploads/scrobotron/b</code></li>';
	echo '<li>Uninstalling the plugin leaves both libraries in place.</li>';
	echo '</ul>';
	echo '<h2>Who can get in</h2>';

	$gated = ( '' !== scrobotron_passkey() );
	if ( $gated ) {
		echo '<div class="notice notice-info inline"><p><strong>The passkey gate is on.</strong> Visitors must enter the shared passkey before the page loads. You (signed in) skip it.</p></div>';
	} else {
		echo '<p><strong>Anyone.</strong> The page is public — no sign-in, no password. Visitors can add GIFs and write captions.</p>';
	}
	echo '<ul style="list-style:disc;margin-left:20px">';
	echo '<li>Only administrators can delete. Visitors never see a Remove button.</li>';
	echo '<li>Uploads must be real GIFs, under 12 MB, and one visitor is capped at 40 per hour.</li>';
	echo '<li>The libraries are shared, so anything a visitor makes shows up here for everyone.</li>';
	echo '</ul>';
	echo '<h3>Put it behind a passkey</h3>';
	echo '<p>Add a single shared passkey without touching this plugin: copy <code>install/scrobotron-passkey.php</code> from the plugin folder into <code>wp-content/mu-plugins/</code>, then edit the one line to set your phrase. Full notes are in <code>install/PASSKEY-INSTALL.md</code>. Delete the file to make the page public again.</p>';
	echo '<p>To require a WordPress login instead, add this to your theme\'s <code>functions.php</code>:<br>';
	echo '<code>add_filter( \'scrobotron_capability\', function () { return current_user_can( \'upload_files\' ); } );</code></p>';
	echo '</div>';
}

/**
 * Copy GIFs into a library without clobbering anything already there.
 * Used by the starter-GIFs package; safe to call more than once.
 *
 * @param string $which 'a' or 'b'
 * @param string $dir   folder of .gif files to copy in
 * @return int number of files actually added
 */
function scrobotron_seed_from( $which, $dir ) {
	$files = glob( untrailingslashit( $dir ) . '/*.gif' );
	if ( ! $files ) { return 0; }
	$dest = scrobotron_dir( $which );
	$n    = 0;
	foreach ( $files as $f ) {
		$to = $dest['path'] . '/' . wp_basename( $f );
		if ( file_exists( $to ) ) { continue; }   // never overwrite your library
		if ( @copy( $f, $to ) ) { @chmod( $to, 0644 ); $n++; }
	}
	return $n;
}

require_once SCROBOTRON_DIR . 'includes/rest.php';
