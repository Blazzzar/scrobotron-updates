<?php
/**
 * Scrobotron passkey — drop-in.
 *
 * WHERE THIS GOES
 *   wp-content/mu-plugins/scrobotron-passkey.php
 *   (mu-plugins = "must-use" plugins. WordPress loads every .php in that folder
 *    automatically — there is no Activate step, and a Scrobotron update can't
 *    overwrite it. If the mu-plugins folder doesn't exist yet, create it.)
 *
 * WHAT IT DOES
 *   Turns on the shared-passkey gate. Anyone who hasn't entered the passkey sees
 *   a prompt instead of the tool. Signed-in users who can upload files skip it.
 *   It is one shared phrase for the whole site, not a per-person login.
 *
 * SET YOUR PASSKEY
 *   Replace CHANGE-ME below with the phrase you want, save, and upload the file.
 *   To change it later, edit this line and re-upload — everyone will have to
 *   enter the new phrase (old sessions stop working). To make the page public
 *   again, delete this file.
 *
 * TIP: serve the site over HTTPS. A passkey typed over plain http can be read in
 *   transit. The gate cookie is already marked Secure on HTTPS.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_filter( 'scrobotron_passkey', function () {
	return 'CHANGE-ME';
} );
