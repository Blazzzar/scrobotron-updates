# Scrobotron — passkey gate

Put the Scrobotron page behind a single shared passkey. Off by default: with no
passkey set, the page stays public exactly as before.

This is a **shared phrase for the whole site**, not a per-person login. It keeps
the casual public out; it is not account-grade security. Serve the site over
**HTTPS** so the passkey isn't readable in transit.

## Install (the short version)

1. In your site's files, find the folder **`wp-content/mu-plugins/`**.
   If it doesn't exist, create it (exactly that name, lowercase).
2. Copy **`scrobotron-passkey.php`** (next to this file) into that folder, so you
   end up with:

   ```
   wp-content/mu-plugins/scrobotron-passkey.php
   ```

3. Open it and change one line — replace `CHANGE-ME` with your passkey:

   ```php
   add_filter( 'scrobotron_passkey', function () {
       return 'let-me-in';   // <- your passkey
   } );
   ```

4. Save. That's it — no "Activate" step. Load the Scrobotron page and you'll get
   the passkey prompt. Visitors enter the phrase once and stay in for 30 days
   (per browser).

> **Which folder?** `wp-content/mu-plugins/`. That's the only place this file
> goes. "mu" is *must-use* — WordPress auto-loads everything there, and plugin
> updates never touch it.

## Changing or removing the passkey

- **Change it:** edit the phrase in the file and re-upload. Everyone (including
  people already let in) will have to enter the new phrase.
- **Turn the gate off:** delete `wp-content/mu-plugins/scrobotron-passkey.php`.
  The page goes public again.

## Alternative: set it in wp-config.php

If you'd rather not use a mu-plugin, add this above the
`/* That's all, stop editing */` line in `wp-config.php`:

```php
define( 'SCROBOTRON_PASSKEY', 'let-me-in' );
```

Use one or the other, not both. The mu-plugin filter wins if both are present.

## Good to know

- **Signed-in staff skip the prompt.** Anyone who can upload files (you) goes
  straight in.
- **The JSON API is gated too.** The add/list endpoints require the same passkey
  cookie, so the gate can't be walked around via the REST URL.
- **Admin check:** Media → Scrobotron shows whether the gate is currently on.
- **Brute force:** the prompt throttles to about 10 tries per few minutes per
  visitor.
