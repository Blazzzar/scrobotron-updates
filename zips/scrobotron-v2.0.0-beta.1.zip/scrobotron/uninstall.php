<?php
/**
 * Scrobotron uninstall. Libraries are your files, so they are LEFT IN PLACE.
 * To remove them too, delete wp-content/uploads/scrobotron/ by hand.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
