# Scrobotron changelog

One line of truth per build. The build script refuses to zip a version
that has no section here. (History before 1.7.0 reconstructed from the
project handover when the repo was created — those builds predate git.)

## 2.0.0-beta.1
The assimilation flow: a "PREPARE TO BE ASSIMILATED" splash gate, capture/assimilation stage theatre (scan beam, hex lattice, status console, stamps), a Shift+W workbench (app theme incl. logo/display font + caption defaults), four new robotic caption fonts (Dotmatrix/LCD/Stencil/Mecha) plus a classic Subtitle style, capture-by-URL and optional Tenor GIF search, and the ghost underlay is now OFF by default (workbench opt-in) — the full-caption "shadow underlay" glitch is gone.

## 1.7.0
Self-updater added: Scrobotron now updates itself from its own GitHub release channel (STEMMAXXER/WeIdea pipeline) — check-now, stable/beta channel switch, and one-click rollback on the Plugins screen. No app changes. This build is installed manually once; everything after rides the pipeline.

## 1.6.0
Libraries renamed Captured/Assimilated (folders and REST unchanged). Stripping moved back to caption time — sources are Captured exactly as they arrive. Mobile paste-to-add. Optional shared-passkey gate (mu-plugin drop-in, off by default).

## 1.5.2
Shadow reveal fix: the dark backing no longer appears under words that have not been revealed yet — shadow belongs to the lit word.

## 1.5.x
Fonts locked by measurement: DSEG14 Classic Bold (readout), VT323 (terminal), Silkscreen (arcade), each with its native glow colour. Shared GIF palette seeded with the LED text colours.

## 1.3.0
Two-step flow introduced (drop → library → caption → library). Strip-on-ingest (later reverted in 1.6.0). Delete hardened: filenames matched against the real directory listing, never rebuilt by sanitising.

## 1.0.0
First working plugin: browser-side GIF decode/compose, caption + watermark detection and removal, LED caption rendering, REST-backed libraries at /scrobotron.html.
