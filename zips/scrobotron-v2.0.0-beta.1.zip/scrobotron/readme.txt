=== Scrobotron ===
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.0.0-beta.1
License: GPL-2.0-or-later

Replaces the caption on an animated GIF with retro 14-segment LED type.

== Description ==

Scrobotron finds the caption and watermark already burned into an animated GIF,
strips them out, and writes a new caption in 14-segment LED type (green phosphor,
CRT scanlines, word-by-word reveal). It replaces the caption — it does not add.

The flow is two steps:

1. Drop or paste a GIF into Captured. It is stored exactly as it arrived —
   nothing is stripped on the way in.
2. Pick one at the Assimilator and write your caption. The old caption and
   watermark are stripped as the new caption is burned in, and the finished GIF
   lands in Assimilated.

All GIF processing happens in the browser. Nothing is sent to a third party and
the server needs no image tooling.

Optionally, put the whole page behind a single shared passkey — see the FAQ.

== Installation ==

1. Plugins → Add New → Upload Plugin → choose scrobotron.zip → Install → Activate.
2. That's it. Activation registers the /scrobotron.html route and creates both
   library folders. Nothing to configure.
3. Go to Media → Scrobotron. It tests the live URL and tells you if anything
   needs fixing (and exactly how).

== Frequently Asked Questions ==

= Who can use it? =
Anyone. The page is public — no account, no password. Visitors can add GIFs and
write captions, but cannot delete anything.

Because the upload endpoint is open to the internet, three guards are on by
default: uploads must be real GIFs, they are capped at 12 MB, and a single
visitor can add at most 40 per hour.

To require a login again:
`add_filter( 'scrobotron_capability', function () { return current_user_can( 'upload_files' ); } );`

To change or lift the hourly cap:
`add_filter( 'scrobotron_rate_limit', function () { return 100; } );`

= Who can delete GIFs? =
Administrators only — you. Deleting is permanent, so it stays stricter than using
the tool. The public can add GIFs and write captions but cannot remove anything,
and they never even see a Remove button.

If you add a second administrator and want deletion limited to just you, name
yourself (your ID is in the URL on Users -> your profile):
`add_filter( 'scrobotron_owner_ids', function () { return array( 1 ); } );`

= Can I put it behind a password? =
Yes — a single shared passkey for the whole site (not a per-person login). Copy
`install/scrobotron-passkey.php` from the plugin into `wp-content/mu-plugins/`
and edit the one line to set your phrase. Full steps are in
`install/PASSKEY-INSTALL.md`. Signed-in staff skip the prompt, the JSON API is
gated too, and deleting the file makes the page public again. Serve the site
over HTTPS.

= Where do the GIFs live? =
wp-content/uploads/scrobotron/a (Captured) and /b (Assimilated). The folder names
stay a/b; only the labels changed. Uninstalling leaves them alone.

= Can I change the URL? =
`add_filter( 'scrobotron_slug', fn() => 'gifs.html' );` then re-save Permalinks.

= The page 404s =
Re-save Settings → Permalinks once. If it still 404s, your web server is serving
.html as a static file and never handing the request to WordPress. Either let
scrobotron.html fall through to WordPress, or drop the extension:
`add_filter( 'scrobotron_slug', function () { return 'scrobotron'; } );`
Media → Scrobotron checks this for you and shows the fix.

== Credits ==

Fonts are bundled under the SIL Open Font License:

* DSEG14 Classic by keshikan
* VT323 by Peter Hull
* Silkscreen by Jason Kottke
* Workbench by Vernon Adams / NDISCOVER
* Iceland by Aleksandra & Kosta Radenkovic
* Saira Stencil One by Omnibus-Type
* Chakra Petch by Cadson Demak

GIF search, when enabled, is powered by Tenor.

== Changelog ==

= 2.0.0-beta.1 =
* The assimilation flow. A "PREPARE TO BE ASSIMILATED" splash greets every
  visit; the three stages are now Capture → Assimilation → Assimilated, with
  proper theatre: a scan beam and status console while a specimen is captured,
  a hex lattice and progress blocks while it assimilates.
* Shift+W opens the Workbench: retheme the app (logo/display font — changes the
  logo and everywhere that font appears — UI font, size, accent colour) and set
  caption defaults. Saved in your browser; RESET returns to factory.
* Four new robotic caption fonts, chosen by measurement like the first three:
  Dotmatrix (Workbench flip-dot, orange), LCD (Iceland, white), Stencil (Saira
  Stencil One, yellow), Mecha (Chakra Petch, red). Plus Subtitle — the classic
  GIF caption look: white Helvetica with a black outline, no scanlines.
* Fixed the "shadow underlay" glitch: the whole caption no longer sits dim
  under the animating words. That was the ghost (unlit-segment) effect, on by
  default for two fonts — it is now off everywhere unless you switch it on in
  the Workbench.
* Capture by URL: paste a direct .gif link and the site fetches it (guarded:
  GIF-only, size-capped, no local addresses). Optional GIF search appears when
  a Tenor API key is set (option scrobotron_tenor_key or the
  SCROBOTRON_TENOR_KEY constant).

= 1.7.0 =
* Scrobotron now updates itself from its own GitHub release channel
  (STEMMAXXER/WeIdea pipeline). The Plugins screen gains "Check for
  updates", a stable/beta channel switch, and one-click "Roll back to X".
  This build must be installed manually once (Upload Plugin → Replace
  current); every build after it arrives as a normal one-click update.
* No changes to the app itself.

= 1.6.0 =
* Renamed the libraries: Library A is now "Captured", Library B is now
  "Assimilated". The folders and REST endpoints are unchanged (still a/b).
* Stripping moved back to caption time. GIFs are now Captured exactly as they
  arrive; the old caption and watermark are stripped by the Assimilator when you
  write the new caption. (Reverts the 1.3.0 strip-on-ingest behaviour.)
* Mobile: you can now add a GIF by pasting it from the clipboard. A Paste button
  sits under the drop zone, and Ctrl/Cmd-V works too.
* New optional shared-passkey gate. Off by default. Drop
  install/scrobotron-passkey.php into wp-content/mu-plugins/ to switch it on;
  the page and the JSON API both require the passkey, signed-in staff skip it.

= 1.5.2 =
* Fixed: the caption's drop shadow appeared for the whole phrase at once, so a
  dark blob sat under words that had not been revealed yet and the colour
  crawled across it. The shadow now arrives word by word with the text.

= 1.5.1 =
* The drop zone is now the CAPTION SHREDDER: dotted green outline, dotted grid
  background, and it glows amber while it is chewing through a GIF.

= 1.5.0 =
* The page is now public. No sign-in or password to use it.
* Deleting is unchanged: administrators only.
* Added guards suited to an open door — a 40-per-hour upload cap per visitor, on
  top of the existing GIF check and 12 MB limit.

= 1.4.0 =
* Three fonts instead of one: Readout (segment LED, green), Terminal (VT323 CRT,
  amber) and Arcade (Silkscreen pixel, cyan). Each switches to the colour its
  real counterpart glowed, and the colour picker still overrides freely.
* Terminal fits roughly twice as much text at the same width, so long captions
  no longer shrink to nothing.
* Fonts are bundled (SIL Open Font License); nothing is fetched from Google.

= 1.3.0 =
* New flow: GIFs are stripped of their caption and watermark as they are dropped
  into Library A, instead of during captioning. Library A is now always clean.
* Fixed a bad watermark false positive: any small persistently-bright spot (a
  highlight, a lamp) could be mistaken for a logo and painted over, damaging the
  picture. Detection now requires a logo to sit low in the frame and be wider
  than it is tall. Re-adding an already-clean GIF is now a no-op.
* Owner-only "Empty Library A / B" buttons.

= 1.2.1 =
* Fixed: Remove did nothing for Library B GIFs. WordPress collapses runs of
  hyphens in filenames, so a name like "source--caption.gif" was looked up as
  "source-caption.gif" and quietly missed. Files are now matched against the real
  directory listing, so any filename works.
* Fixed: a failed delete reported success. It now returns a proper error and the
  page tells you what went wrong.

= 1.2.0 =
* Running a GIF through now saves a CLEAN copy back to Library A, stripped of its
  original caption and watermark, so Library A becomes a reusable source library.
* Watermarks are now detected and removed (previously only captions were).
* Library previews are larger and show the whole frame instead of cropping it.
* Click any GIF to open it in a large viewer, with use / save / remove there.

= 1.1.0 =
* Deleting is now restricted to administrators. Everyone else can add and
  replace but never remove, and the Remove button is hidden from them.
* Deleting asks for confirmation first.
* Adds a seeding hook so the Starter GIFs package can fill your libraries.

= 1.0.1 =
* Routing hardened: the .html path is now matched directly as well as by rewrite
  rule, so it survives another plugin flushing rules or a site migration.
* Rewrite rules self-heal if they go missing.
* Media → Scrobotron now fetches the live URL and reports real status plus fixes.

= 1.0.0 =
* First release: Library A/B, caption detection and replacement, LED rendering,
  cover or extend placement, zip download.
